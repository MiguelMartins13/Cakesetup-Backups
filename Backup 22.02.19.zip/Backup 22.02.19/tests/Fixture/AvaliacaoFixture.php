<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * AvaliacaoFixture
 *
 */
class AvaliacaoFixture extends TestFixture
{

    /**
     * Table name
     *
     * @var string
     */
    public $table = 'avaliacao';

    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_aval' => ['type' => 'integer', 'length' => 3, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'autoIncrement' => true, 'precision' => null],
        'id_user' => ['type' => 'integer', 'length' => 3, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'id_jogo' => ['type' => 'integer', 'length' => 3, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'comentario' => ['type' => 'string', 'length' => 256, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => '', 'precision' => null, 'fixed' => null],
        'n_estrelas' => ['type' => 'integer', 'length' => 10, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'datahora' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null],
        '_indexes' => [
            'id_user' => ['type' => 'index', 'columns' => ['id_user'], 'length' => []],
            'id_jogo' => ['type' => 'index', 'columns' => ['id_jogo'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_aval'], 'length' => []],
            'avaliacao_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_user'], 'references' => ['users', 'id_user'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'avaliacao_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_user'], 'references' => ['users', 'id_user'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'avaliacao_ibfk_3' => ['type' => 'foreign', 'columns' => ['id_jogo'], 'references' => ['jogos', 'id_jogo'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd

    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_aval' => 1,
                'id_user' => 1,
                'id_jogo' => 1,
                'comentario' => 'Lorem ipsum dolor sit amet',
                'n_estrelas' => 1,
                'datahora' => '2019-02-14 12:52:15'
            ],
        ];
        parent::init();
    }
}
