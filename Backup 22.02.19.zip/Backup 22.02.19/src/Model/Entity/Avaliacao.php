<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Avaliacao Entity
 *
 * @property int $id_aval
 * @property int $id_user
 * @property int $id_jogo
 * @property string $comentario
 * @property int $n_estrelas
 * @property \Cake\I18n\FrozenTime $datahora
 */
class Avaliacao extends Entity
{

    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id_user' => true,
        'id_jogo' => true,
        'comentario' => true,
        'n_estrelas' => true,
        'datahora' => true
    ];
}
