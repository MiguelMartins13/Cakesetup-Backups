<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Avaliacao Model
 *
 * @method \App\Model\Entity\Avaliacao get($primaryKey, $options = [])
 * @method \App\Model\Entity\Avaliacao newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Avaliacao[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Avaliacao|bool save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Avaliacao|bool saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Avaliacao patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Avaliacao[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Avaliacao findOrCreate($search, callable $callback = null, $options = [])
 */
class AvaliacaoTable extends Table
{

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('avaliacao');
        $this->setDisplayField('id_aval');
        $this->setPrimaryKey('id_aval');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id_aval')
            ->allowEmptyString('id_aval', 'create');

        $validator
            ->integer('id_user')
            ->requirePresence('id_user', 'create')
            ->allowEmptyString('id_user', false);

        $validator
            ->integer('id_jogo')
            ->requirePresence('id_jogo', 'create')
            ->allowEmptyString('id_jogo', false);

        $validator
            ->scalar('comentario')
            ->maxLength('comentario', 256)
            ->requirePresence('comentario', 'create')
            ->allowEmptyString('comentario', false);

        $validator
            ->integer('n_estrelas')
            ->requirePresence('n_estrelas', 'create')
            ->allowEmptyString('n_estrelas', false);

        $validator
            ->dateTime('datahora')
            ->requirePresence('datahora', 'create')
            ->allowEmptyDateTime('datahora', false);

        return $validator;
    }
}
